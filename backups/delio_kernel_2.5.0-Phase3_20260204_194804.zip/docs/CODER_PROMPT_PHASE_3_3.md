# 🛠️ ENGINEERING GUIDE: PHASE 3.3 (Vision, Voice, Kernel Backup)

## 🎯 Context
We are finalizing Phase 3 by adding sensory capabilities (Vision, Voice) and preparing a clean "Golden Image" backup of the kernel.

## 🧱 Work Zone

### 1. Task 007: Vision (👁️)
- **File**: `handlers.py`
    - Update Message Handler to accept `F.photo`.
    - Download photo to `/tmp/vision_buffer/`.
- **File**: `core/llm_service.py`
    - Update `call_actor` to accept `image_path`.
    - Use `genai.upload_file` + prompt injection.
- **Rules**:
    - Only process photos if User Trust Level >= 1 (prevent spam).
    - Auto-cleanup `/tmp` after processing.

### 2. Task 008: Voice (🎙️)
- **File**: `core/tts_service.py` (CREATE)
    - Wrapper for `edge_tts`.
    - Function: `generate_speech(text: str, voice="uk-UA-OstapNeural") -> path`.
- **File**: `scheduler.py`
    - Update `send_morning_briefing`: Generate Audio -> Send Voice Message.
- **Constraint**: Text messages > 250 chars in Morning Briefing should be converted to audio.

### 3. Kernel Backup (💾)
- **File**: `scripts/freeze_kernel.py` (CREATE)
    - **Logic**:
        - Walk through `/core`, `/states`, `/tools`.
        - Ignore `__pycache__`, `.git`, `data/*.db` (EXCEPT schemas).
        - Zip into `backups/delio_kernel_v2.5.zip`.
    - **Manifest**: Create `KERNEL_MANIFEST.json` inside zip with version info.

## 📜 Coder Instruction
1.  **Vision First**: Verify you can send a cat photo and Gemini says "It's a cat".
2.  **Voice Second**: Verify `Morning Briefing` comes as a vocal message.
3.  **Backup Last**: Run the script and verify the ZIP size is small (< 2MB) and contains NO user data.

## ⚠️ Safety
- **Vision**: Do not log image binaries to `bot.log`. Log only file paths.
- **Voice**: Ensure `edge-tts` is installed (`pip install edge-tts`).
