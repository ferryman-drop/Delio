# 🚀 QUICK START - Швидкий старт

## За 5 хвилин до запуску бота

### 1️⃣ Клонування шаблону .env (1 хвилина)

```bash
cd /root/ai_assistant
cp .env.example .env
```

### 2️⃣ Заповнення ключів API (2 хвилини)

Відкрийте `.env` і вставте ваші ключі:

```bash
nano .env
```

Знайдіть і заповніть:
```
TG_TOKEN=your_telegram_token_here
GEMINI_KEY=your_gemini_key_here
DEEPSEEK_KEY=your_deepseek_key_here
```

### 3️⃣ Встановлення залежностей (1 хвилина)

```bash
source venv/bin/activate
pip install -r requirements.txt
```

### 4️⃣ Запуск бота (1 хвилина)

**Варіант А: Розробка (видіть логи в реальному часі)**
```bash
python main.py
```

**Варіант Б: Production (фоновий режим)**
```bash
nohup python main.py &
```

### 5️⃣ Тестування (відправте боту в Telegram)

```
/start   - Привіт від бота
/help    - Список команд
/stats   - Ваша статистика
Hello!   - Будь-яке повідомлення для AI
/history - Переглянути контекст
/clear   - Очистити контекст
```

---

## 📋 Команди бота

| Команда | Результат |
|---------|-----------|
| `/start` | 🤖 Привіт та інформація |
| `/help` | 📚 Довідка про бота |
| `/history` | 📜 Останні 5 повідомлень |
| `/clear` | 🗑️ Очистити контекст |
| `/stats` | 📊 Ваша статистика |
| `Будь-що` | 🚀 Відповідь від AI (DeepSeek → Gemini) |

---

## 🔍 Монітор роботи

### Перегляд логів в реальному часі

```bash
tail -f bot.log
```

### Перевірка статусу процесу

```bash
ps aux | grep "python main.py"
```

### Зупинення бота

```bash
pkill -f "python main.py"
```

---

## 📁 Важливі файли

- **main.py** - Основний код (з командами, логуванням, БД)
- **bot.log** - Логи роботи (автоматично створюється)
- **.env** - Ваші API ключі (НЕ комітьте в Git!)
- **config.yaml** - Конфігурація (опціонально)
- **data/chat_history.db** - SQLite база (автоматично створюється)

---

## 🆘 Проблеми

### Проблема: "ModuleNotFoundError: No module named 'aiogram'"

**Рішення:**
```bash
source venv/bin/activate
pip install -r requirements.txt
```

### Проблема: "Invalid API key"

**Рішення:**
1. Перевірте що ключі в `.env` скопійовані правильно
2. Переконайтеся що нема пробілів в кінці
3. Переконайтеся що ключи активні на відповідних сайтах

### Проблема: Бот не відповідає

**Рішення:**
1. Перевірте логи: `tail -f bot.log`
2. Перезавантажте: `pkill -f "python main.py" && python main.py`
3. Перевірте інтернет

---

## 📊 Що нового в v2.0.0

✨ **Додано:**
- 5 нових команд (/start, /help, /history, /clear, /stats)
- SQLite база даних для збереження історії
- Файл логування (bot.log) з деталями
- .env конфігурація для безпеки
- requirements.txt для управління залежностями
- config.yaml для розширеної конфігурації
- .gitignore для Git безпеки
- 24 юніт-тести (все працює!)

---

## 💡 Корисні команди

```bash
# Активація venv
source venv/bin/activate

# Запуск тестів
python -m pytest test_bot.py -v

# Перевірка синтаксису Python
python -m py_compile main.py

# Вивід версії Python
python --version

# Перегляд процесу в реальному часі
watch -n 1 'ps aux | grep python'

# Розмір логу
ls -lh bot.log

# Кількість рядків в логу
wc -l bot.log

# Остаток свіжих записів в логу
tail -20 bot.log
```

---

## 🎯 Наступні кроки

1. ✅ Налаштуйте `.env` 
2. ✅ Запустіть `python main.py`
3. ✅ Напишіть `/start` боту
4. ✅ Протестуйте команди
5. ✅ Перевірте `bot.log`
6. ✅ Відправте повідомлення AI

---

**Що робити далі?** Читайте [README.md](README.md) та [CHANGES.md](CHANGES.md) для більш детальної інформації!

Успіхів! 🚀
